#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;
int main()
{
vector<int> v(10,1);
cout << v[1];

return 1;
}
