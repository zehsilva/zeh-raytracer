Vec3f.hh -> Cria um vetor 3D e operacoes aritmeticas 	
Basic.hh -> Cria a estrutura de raios 3D, shader, primitivas geometricas e cameras
Triangle.hh -> Classe para lidar com triangulos
Sphere.hh -> Classe para lidar com spheres
FlatShader.hh -> Um tipo simples de Shader
PhongShader.hh -> Phong shader
Image.hh -> Code to save the images
InfinitePlane.hh -> Classe para lidar com planos
PerspectiveCamera.hh -> Classe para lidar com perp. camera - alterado usando o angulo
Scene.hh -> Classe para lidar com a cena
Group.hh -> Classe para lidar com um grupo de figuras geometricas
Render.cpp -> Main file

testreflect.nff -> Arquivo de test
 