#include "PhongShader.hh"
#include <math.h>
void PhongShader::ReflectRefract(Vec3f &ray)
{
  // Escreva o codigo aqui
}

Vec3f PhongShader::Shade(Ray &ray)
{

  Vec3f normal = ray.hit->GetNormal(ray);


  if (Dot(normal,ray.dir) > 0) {
    normal = -normal;
  }

  Vec3f reflect = ray.dir - 2*Dot(normal,ray.dir)*normal;

  // Ia
  Vec3f ambientIntensity(1,1,1);
  Vec3f ambientColor = ka * color;
  Vec3f result = ambientColor*ambientIntensity;


  // shadow ray
  Ray shadow;
  shadow.org = ray.org + ray.t * ray.dir;

  // iterate over all light sources
  for (unsigned int l=0; l < scene->lights.size(); l++)
  {
    // get direction to light, and intensity
    Vec3f lightIntensity;
    Vec3f result_local = Vec3f(0.0f,0.0f,0.0f);

    lightIntensity=scene->lights[l]->Illuminate(shadow, lightIntensity);

    // compute distance to the light source
    float distance = shadow.t;

    // diffuse term, also used as a check if illuminating the front-side
    float cosLightNormal = Dot(shadow.dir,normal);
    if (cosLightNormal > 0)
    {
      if(scene->primitives.Intersect(shadow))
      {
        if (shadow.t < distance)
          continue;
      }

      // compute diffuse term
      Vec3f diffuseColor = kd * color;
      result_local = result_local + (diffuseColor * cosLightNormal)*lightIntensity;

      // specular term is computed only if shading the front-side
      float cosLightReflect = Dot(shadow.dir,reflect);
      if (cosLightReflect > 0)
      {
        Vec3f specularColor = ks * Vec3f(1,1,1); // white highlight;
        result_local = result_local + specularColor * powf(cosLightReflect,kg) * lightIntensity;
      }
    }
    result=result+ result_local;
    //result += (result_local / float(scene->lights.size()));
  }

  return result;
}










