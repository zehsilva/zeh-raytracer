#ifndef PHONGSHADER_HXX
#define PHONGSHADER_HXX

#include "Basic.hh"
#include "Scene.hh"

class PhongShader : public Shader
{
public:
  Vec3f color;
  float ka, ks, kd, kg;
  float reflexive,transparency;
  Scene* scene;
  PhongShader(Vec3f color, float ka, float ks, float kd, float kg,Scene *scene,float rl,float tp)
    : color(color), ka(ka), ks(ks), kd(kd), kg(kg), scene(scene), reflexive(rl), transparency(tp)
  {};

  ~PhongShader()
  {};

  void ReflectRefract(Vec3f &ray);
  virtual Vec3f Shade(Ray &ray);

};

#endif



