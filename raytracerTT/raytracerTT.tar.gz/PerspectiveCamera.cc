#include "PerspectiveCamera.hh"

void PerspectiveCamera::InitRay(float x, float y, Ray &ray)
{
  // Escreva o codigo aqui
  Vec3f vp = dir_X*2.0f * ((x/(float)resX - .5f)*aspect)+dir_Y*2.0f * (y/(float)resY - .5f)+dir*focus;
  //ray.dir  = vp + dir*tan(angle/2);
  //ray.dir  = Vec3f(10,x,y);
  ray.dir= vp;
  ray.org = pos;


  Normalize(ray.dir);
}

