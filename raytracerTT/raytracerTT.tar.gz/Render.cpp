#include "Image.hh"
#include "Basic.hh"
#include "Sphere.hh"
#include "Triangle.hh"
#include "InfinitePlane.hh"
#include "PerspectiveCamera.hh"
#include "FlatShader.hh"
#include "DiffuseShader.hh"
#include "Scene.hh"
#include <time.h>

using namespace std;

Image *Render(char *filename)
{
  int depth = 3;
  bool antialiasing=true;
  Scene	scene(depth);
  scene.ParseNFF(filename);

  Image	*img;
  int	RES_X, RES_Y;
  RES_X = ((PerspectiveCamera *)scene.camera)->resX;
  RES_Y = ((PerspectiveCamera *)scene.camera)->resY;
  img = new Image(RES_X, RES_Y);
  if(!img)
    return NULL;
  img->Clear();


  for(int j = 0; j < RES_Y; j++)
    for(int i = 0; i < RES_X; i++)
      {

        int k1,k2,initAA,endAA;
        Vec3f coltemp(0,0,0);
        if(antialiasing)
        {
          initAA=-1;
          endAA=2;//anti-aliasing
        }else
        {
          initAA=0;
          endAA=0;
        }

        for(k1=initAA;k1<endAA;k1++)
          for(k2=initAA;k2<endAA;k2++)
          {
            Ray	ray;
            scene.rayDepth = 0;
	          scene.camera->InitRay(i+k1*0.1, j+k2*0.1, ray);
	          coltemp=coltemp+scene.RayTrace(ray);

          }
	      Vec3f	color = coltemp/((k1+1)*(k2+1));
	      //if(color!=scene.bgColor)
	       // cout << " pixel x y = " << i << "," << j << " ";

	      img->SetValuePixel(i, j, color);
      }
  return img;
}

int main(int argc, char *argv[])
{
  if(argc < 3)
    {
      printf("render <inputfile> <outputfile>\n");
      return 0;
    }

  printf("Rendering %s...\n", argv[1]);
  time_t t1 = time(&t1);
  Image	*img = Render(argv[1]);
  time_t t2 = time(&t2);
  printf("Now saving %s...\n", argv[2]);

  printf("Rendering Time = %d seg\n", (int)t2 - (int)t1);

  if(img->SavePPM(argv[2]) < 0)
    printf("Cannot save the file %s.\n", argv[2]);
  delete img;

  return 0;
}



