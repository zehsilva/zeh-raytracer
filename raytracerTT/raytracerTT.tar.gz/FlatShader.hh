#ifndef FLATSHADER_HXX
#define FLATSHADER_HXX

#include "Basic.hh"

class FlatShader : public Shader
{
public:
  Vec3f color;
  
  FlatShader();
  FlatShader(Vec3f color)
    : color(color)
  {};
  
  ~FlatShader()
  {};
  
  virtual Vec3f Shade(Ray &ray);
};

inline Vec3f FlatShader::Shade(Ray &ray)
{
  return color;
}

#endif
